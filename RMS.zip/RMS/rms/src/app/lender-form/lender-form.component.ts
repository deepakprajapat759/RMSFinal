import { Component, OnInit } from '@angular/core';
import { Lender } from '../model/lender';
import { ActivatedRoute, Router } from '@angular/router';
import { LenderService } from '../service/lender.service';

@Component({
  selector: 'app-lender-form',
  templateUrl: './lender-form.component.html',
  styleUrls: ['./lender-form.component.css']
})
export class LenderFormComponent {

  lender:Lender;

  constructor(private route: ActivatedRoute, private router:Router,private lenderService:LenderService) {
    this.lender= new Lender();
  }

  onSubmit(){
    this.lenderService.save(this.lender).subscribe();
  }

}
