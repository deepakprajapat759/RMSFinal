export class Lender {
    userName: string;
    userEmail: string;
    userPassword:string;
    tenureRange:string;
    loanInterest:string;
    lenderDescription:string;
    loanAmountRange:string;
}
