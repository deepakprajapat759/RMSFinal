export class User {

    userName: string;
    userEmail: string;
    userPassword:string;
    //userRole:string;
    //userAIStatus:number;
    //creationDate:Date;
    //modificationDate:Date;
}
