package com.casestudy.rms.controller;
/**
 * Represents Financial Analyst Controller.
 * @author impetus
 *
 */
public class FinancialAnalystController {

}
