package com.casestudy.rms.controller;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.rms.model.FinancialAnalyst;
import com.casestudy.rms.model.Lender;
import com.casestudy.rms.service.ILenderService;

/**
 * Represents Lender Controller.
 * @author impetus
 *
 */
@RestController
@RequestMapping("/rms/lender")
@CrossOrigin(origins = {"http://localhost:4200"})
public class LenderController {
    
    @Autowired
    private ILenderService lenderService;
    
    /**
     * Register a Lender.
     * @param lender - Lender
     * @return Status
     */
    @RequestMapping(value="/registerlender", consumes="application/JSON", method=RequestMethod.POST)
    public ResponseEntity<Void> registerLender(@RequestBody Lender lender){
        boolean flag = lenderService.registerLender(lender);
        if (flag) {
            return new ResponseEntity<Void>(HttpStatus.CREATED);
        }else {
            
            return new ResponseEntity<Void>(HttpStatus.CONFLICT);
        }
    }
    
   
    /**
     * Add Financial Analysts.
     * @param financialAnalyst - Financial Analyst
     * @param id - Lender ID
     * @return Status
     */
    @RequestMapping(value="/addFinancialAnalyst", consumes="application/JSON", method=RequestMethod.POST)
    public ResponseEntity<Void> addFinancialAnalyst(@RequestBody FinancialAnalyst financialAnalyst, @RequestParam("id") int id){
        Lender lender = lenderService.getLender(id); 
        boolean flag = lenderService.addFinancialAnalyst(financialAnalyst,lender);
        if (flag) {
            return new ResponseEntity<Void>(HttpStatus.CREATED);
        }else {
            
            return new ResponseEntity<Void>(HttpStatus.CONFLICT);
        }
        
    }

}
