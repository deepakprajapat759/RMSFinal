package com.casestudy.rms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.casestudy.rms.model.User;
import com.casestudy.rms.service.IUserService;

/**
 * Represents an User Controller.
 * @author impetus
 *
 */
@RestController
@RequestMapping("/rms")
@CrossOrigin(origins = {"http://localhost:4200"})
public class UserController {
	
	@Autowired
	private IUserService userService;
	
	/**
	 * Register a Borrower.
	 * @param user - Borrower
	 * @return Status
	 */
	@RequestMapping(value="/registerborrower", consumes="application/JSON", method=RequestMethod.POST)
	public ResponseEntity<Void> registerBorrower(@RequestBody User user){
		boolean flag = userService.registerBorrower(user);
		if (flag) {
		    return new ResponseEntity<Void>(HttpStatus.CREATED);
		     
		}else {
		    return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		}
	}

}
