package com.casestudy.rms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.casestudy.rms.util.ApplicationConstant;

import com.casestudy.rms.dao.IAdminDAO;
import com.casestudy.rms.model.Lender;

/**
 * Provides services to Administrator.
 * @author impetus
 *
 */
@Service
public class AdminService implements IAdminService{

    @Autowired
    private IAdminDAO adminDAO;
   
    @Override
    public List<Lender> getPendingLenders() {
        
        return adminDAO.getLenderWithStatus(ApplicationConstant.NOT_APPROVED);
    }

    @Override
    public List<Lender> getActiveLenders() {
       
        return adminDAO.getLenderWithStatus(ApplicationConstant.ACTIVE);
    }

    @Override
    public List<Lender> getInactiveLenders() {
        
        return adminDAO.getLenderWithStatus(ApplicationConstant.INACTIVE);
    }

}
