package com.casestudy.rms.service;

import java.util.List;

import com.casestudy.rms.model.Lender;

/** Declare set of services for Administrator.
 * 
 * @author impetus */
public interface IAdminService {
    /** Provides list of Lender that are not approved by Administrator.
     * 
     * @return List of Non-approved lenders */
    List<Lender> getPendingLenders();

    /** Provides list of Lender that are Active.
     * 
     * @return List of Active lenders */
    List<Lender> getActiveLenders();

    /** Provides list of Lender that are Inactive.
     * 
     * @return List of Inactive lenders */
    List<Lender> getInactiveLenders();

}
