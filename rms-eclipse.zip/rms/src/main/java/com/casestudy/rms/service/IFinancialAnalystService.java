package com.casestudy.rms.service;

/**
 * Declares set of services for FinancialAnalystService.
 * @author impetus
 *
 */
public interface IFinancialAnalystService {
    
    

}
