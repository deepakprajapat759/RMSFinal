package com.casestudy.rms.service;

import com.casestudy.rms.model.FinancialAnalyst;
import com.casestudy.rms.model.Lender;

/** Declares set of services for Lender.
 * 
 * @author impetus */
public interface ILenderService {

    /** Register a Lender.
     * 
     * @param lender
     *            - Lender
     * @return Registered or not. */
    boolean registerLender(Lender lender);

    /** Add Financial Analyst to Lender.
     * 
     * @param financialAnalyst
     *            - Financial Analyst
     * @param lender
     *            - Lender
     * @return Added or not. */
    boolean addFinancialAnalyst(FinancialAnalyst financialAnalyst, Lender lender);

    /** Gets Lender corresponding to Lender ID.
     * 
     * @param lenderId
     *            - Lender ID
     * @return Lender */
    Lender getLender(int lenderId);

}
