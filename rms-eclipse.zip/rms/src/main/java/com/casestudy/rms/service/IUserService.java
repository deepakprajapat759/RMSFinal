package com.casestudy.rms.service;

import com.casestudy.rms.model.User;

/** Declare a set of services for User.
 * 
 * @author impetus */
public interface IUserService {

    /** Register a Borrower.
     * 
     * @param user
     *            - User
     * @return Registered or not */
    boolean registerBorrower(User user);
}
