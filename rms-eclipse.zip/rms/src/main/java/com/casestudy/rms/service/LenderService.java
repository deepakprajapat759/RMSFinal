package com.casestudy.rms.service;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.casestudy.rms.dao.IFinancialAnalystDAO;
import com.casestudy.rms.dao.ILenderDAO;
import com.casestudy.rms.model.FinancialAnalyst;
import com.casestudy.rms.model.Lender;
import com.casestudy.rms.util.ApplicationConstant;

/** Provides services to Lender.
 * 
 * @author impetus */
@Service
public class LenderService implements ILenderService {

    @Autowired
    private ILenderDAO lenderDAO;

    @Autowired
    private IFinancialAnalystDAO financialAnalystDAO;

    @Override
    public boolean registerLender(Lender lender) {

        if (lenderDAO.lenderExists(lender))
            return false;
        else {
            lender.setUserAIStatus(ApplicationConstant.ACTIVE);
            lender.setUserRole("ROLE_LENDER");
            lender.setCreationDate(LocalDateTime.now());
            lender.setModificationDate(LocalDateTime.now());
            lenderDAO.registerLender(lender);
            return true;
        }

    }

    @Override
    public boolean addFinancialAnalyst(FinancialAnalyst financialAnalyst, Lender lender) {

        if (financialAnalystDAO.financialAnalystExist(financialAnalyst))
            return false;
        else {
            List<FinancialAnalyst> financialAnalystLst = lender.getFinancialAnalysts();
            financialAnalystLst.add(financialAnalyst);
            lender.setFinancialAnalysts(financialAnalystLst);
            financialAnalyst.setUserAIStatus(ApplicationConstant.ACTIVE);
            financialAnalyst.setUserRole("ROLE_FINANCIALANALYST");
            financialAnalyst.setCreationDate(LocalDateTime.now());
            financialAnalyst.setModificationDate(LocalDateTime.now());
            lenderDAO.addFinancialAnalyst(financialAnalyst);

            return true;
        }
    }

    @Override
    public Lender getLender(int lenderId) {

        return lenderDAO.getLender(lenderId);
    }

}
